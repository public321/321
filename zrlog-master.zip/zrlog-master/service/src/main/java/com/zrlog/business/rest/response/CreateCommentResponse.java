package com.zrlog.business.rest.response;

public class CreateCommentResponse {

    private String alias;

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
}
